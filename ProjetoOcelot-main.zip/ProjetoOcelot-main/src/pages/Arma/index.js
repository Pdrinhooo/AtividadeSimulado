import { Image, TextInput, View, TouchableOpacity, Text } from 'react-native'
import styles from './styles'
import { Link } from '@react-navigation/native';



export default function Arma(){
    return(
        <View style={styles.container}>
            <Image 
                source={require('../../../assets/Kalina_Ann.webp')} 
                style={styles.logo}
            />

            <Text style={styles.itemName}>
                Modelo: Kalina Ann II
            </Text>
            <Text style={styles.itemDescription}>
                Um lança-foguetes com um disparador de ganchos e baioneta integrada, capaz de alto poder explosivo e uma barragem de mísseis.
            </Text>
            
            <View style={styles.viewLinks}>
                <Link to={{screen: 'Espada'}}>
                    <Text style={styles.LinkBtn}>Espada</Text>
                </Link>
                <Link to={{screen: 'Armadura'}}>
                    <Text style={styles.LinkBtn}>Armadura</Text>
                    </Link>
            </View>
        </View>
    )
}