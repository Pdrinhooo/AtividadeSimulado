import { Image, TextInput, View, TouchableOpacity, Text } from 'react-native'
import styles from './styles'
import { Link } from '@react-navigation/native';



export default function Armadura(){
    return(
        <View style={styles.container}>
            <Image 
                source={require('../../../assets/Spartan_Suit.webp')} 
                style={styles.logo}
            />

            <Text style={styles.itemName}>
                Traje: Mjolnir Mk VI
            </Text>
            <Text style={styles.itemDescription}>
            O Mjolnir Mark VI foi a sexta e última das versões dos trajes Mjolnir. O processo foi emitido para os poucos comandos sobreviventes do SPARTAN-II em outubro de 2552, substituindo a variante mais antiga do Mark V. Apesar da introdução do Mjolnir Gen2 após a guerra Humano-Covenant, a armadura Mark VI ainda poderia ser requisitada pelos SPARTAN-IVs em 2558.
            </Text>
            
            <View style={styles.viewLinks}>
                <Link to={{screen: 'Espada'}}>
                    <Text style={styles.LinkBtn}>Espada</Text>
                </Link>
                <Link to={{screen: 'Arma'}}>
                    <Text style={styles.LinkBtn}>Arma</Text>
                    </Link>
            </View>
        </View>
    )
}