import { Image, TextInput, View, TouchableOpacity, Text } from 'react-native'
import styles from './styles'
import { Link } from '@react-navigation/native';



export default function Espada(){
    return(
        <View style={styles.container}>
            <Image 
                source={require('../../../assets/KatanaMurasama.webp')} 
                style={styles.logo}
            />

            <Text style={styles.itemName}>
                Nome da Espada: Murasama
            </Text>
            <Text style={styles.itemDescription}>
            Também conhecida como "Lâmina de alta frequência A VT7". A conversão de alta frequência da espada carregou as já excelentes propriedades da espada original, tornando-a extremamente poderosa. Sam carregava o Murasama embainhado ao seu lado no estilo de samurai (buke-zukuri), o que lhe permitiu sacar rapidamente da postura taito.

A bainha do Murasama continha um mecanismo de rifle com um carregador carregado e um gatilho localizado abaixo do punho da espada.
            </Text>
            
            <View style={styles.viewLinks}>
                <Link to={{screen: 'Armadura'}}>
                    <Text style={styles.LinkBtn}>Armadura</Text>
                </Link>
                <Link to={{screen: 'Arma'}}>
                    <Text style={styles.LinkBtn}>Arma</Text>
                    </Link>
            </View>
        </View>
    )
}